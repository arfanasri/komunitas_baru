<?PHP

	$namaserver = "localhost";
	$username = "root";
	$password = "";
	$namadatabase = "website_komunitas";
	
	$koneksi = mysqli_connect($namaserver, $username, $password, $namadatabase);

?>