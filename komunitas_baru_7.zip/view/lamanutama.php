<?PHP if($_SESSION["level"] == "guest" ){?>
<div class="text-justify">
	<p>Selamat datang Di Situs Laman SISTEM INFORMASI KOMUNITAS PAREPARE BERBASIS WEB.<br><p>
	Di Laman ini akan menjadi sebagai wadah penyebaran informasi secara meluas tentang komunitas komunitas di parepare, dan juga  wadah untuk mempromosikan komunitas agar dapat merekrut banyak anggota.
	Anda para calon peminat juga tidak akan kesulitan mencari informasi lagi tentang komunitas yang anda minati.<br><p>Untuk mengetahui komunitas apa saja yang ada,masuk pada tab menu "Kategori".
	jika ingin mendaftar komunitas Anda, Maka Diharuskan Anda mengisi form pendaftaran pada Tab Menu "Daftar" dan mendapatkan username juga password yang akan Anda pakai mendaftar komunitas baru, begitupun jika ingin bergabung menjadi anggota di komunitas. SELAMAT MENCOBA!</p>
</div>
<?PHP } else { ?>
<div class="text-justify">
	<p>Selamat datang Di Situs Laman User SISTEM INFORMASI KOMUNITAS PAREPARE BERBASIS WEB.<br><p>
	Di Laman ini akan menjadi sebagai wadah penyebaran informasi secara meluas tentang komunitas komunitas di parepare, dan juga  wadah untuk mempromosikan komunitas agar dapat merekrut banyak anggota.
	Anda para calon peminat juga tidak akan kesulitan mencari informasi lagi tentang komunitas yang anda minati.<br><p>Untuk mengetahui komunitas apa saja yang ada,masuk pada tab menu "Kategori".
	jika ingin mendaftar komunitas Anda, Maka Diharuskan Anda mengisi form pendaftaran pada Tab Menu "Daftar" dan mendapatkan username juga password yang akan Anda pakai mendaftar komunitas baru, begitupun jika ingin bergabung menjadi anggota di komunitas. SELAMAT MENCOBA!</p>
</div>
<?PHP } ?>